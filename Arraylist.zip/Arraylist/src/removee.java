import java.util.*;
public class removee{
   public static void main(String args[]){
      ArrayList<String> a1=new ArrayList<String>(); 
      a1.add("hari");
      a1.add("anu");
      a1.add("ram");
      a1.add("sai");
      a1.add("shan");
      a1.add("tanvi");
      System.out.println(a1);

      
      a1.remove("sai");
      a1.remove("shan");

      
      System.out.println(a1);

      
      a1.remove(3);

      
      System.out.println(a1);
   }
}
