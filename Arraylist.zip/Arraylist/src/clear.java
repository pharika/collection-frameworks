import java.util.ArrayList; 
  
public class clear { 
	

    public static void main(String[] args) 
    { 
        
        ArrayList<Integer> a1 = new ArrayList<Integer>(4); 
        a1.add(1); 
        a1.add(2); 
        a1.add(3); 
        a1.add(4); 
  
        System.out.println("The list initially: " + a1); 
  
        a1.clear(); 
        System.out.println("The list after using clear() method: " + a1);
    }
}