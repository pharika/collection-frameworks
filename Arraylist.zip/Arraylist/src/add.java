import java.util.ArrayList; 
	  
	public class add {
	public static void main(String[] args) 
	    { 
		ArrayList<String> a1=new ArrayList<String>(); 
	        a1.add("hari"); 
	        a1.add("anu"); 
	        a1.add("ram"); 
	  
	       System.out.println(a1); 
	        a1.add(2, "rani");
	        System.out.println(a1);
	        
	            
	        } 
	    } 
	


