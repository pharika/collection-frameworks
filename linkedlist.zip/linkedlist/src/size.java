import java.util.LinkedList; 
  
public class size { 
    public static void main(String args[]) 
    {  
        LinkedList<String> list = new LinkedList<String>(); 
        list.add("welcome"); 
        list.add("to"); 
        list.add("java"); 
        list.add("10"); 
        list.add("20");  
        System.out.println("LinkedList:" + list);  
        System.out.println("The size of the linked list is: " + list.size()); 
    } 
} 