import java.util.*;
public class remove{
   public static void main(String args[]){

      LinkedList<String> list=new LinkedList<String>();

      
      list.add("anu");
      list.add("hari");
      list.add("Raj");
      list.add("ram");
      list.add("manu");
      list.removeFirst();
      list.removeLast();
      Iterator<String> iterator=list.iterator();
      while(iterator.hasNext()){
         System.out.print(iterator.next()+" ");
      }
      list.remove(1);

      System.out.print("\nAfter removing second element: ");
      Iterator<String> iterator1=list.iterator();
      while(iterator1.hasNext()){
         System.out.print(iterator1.next()+" ");
      }
   }
}