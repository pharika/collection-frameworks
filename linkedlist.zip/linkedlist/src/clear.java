import java.util.LinkedList; 
  
public class clear { 
    public static void main(String args[]) 
    { 
      LinkedList<String> list = new LinkedList<String>(); 
        list.add("welcome"); 
        list.add("to"); 
        list.add("java"); 
        list.add("10"); 
        list.add("20"); 
   
        System.out.println("Original LinkedList:" + list); 
        list.clear(); 
        System.out.println("List after clearing all elements: " + list);  
        list.add("welcome"); 
        list.add("to"); 
        list.add("java");  
        System.out.println("After adding elements to empty list:" + list); 
    } 
} 
