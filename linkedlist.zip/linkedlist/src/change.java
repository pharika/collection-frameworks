import java.util.*;  
    
public class change {  
    
    public static void main(String args[])  
    {  
        LinkedList<String> ll = new LinkedList<>();  
    
        ll.add("welcome");  
        ll.add("java");  
        ll.add(1, "for");  
    
        System.out.println("Initial LinkedList " + ll);  
    
        ll.set(1, "to");  
    
        System.out.println("Updated LinkedList " + ll);  
    }  
}  
