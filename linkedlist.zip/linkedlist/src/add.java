import java.util.*;
public class add{
   public static void main(String args[]){

     LinkedList<String> list=new LinkedList<String>();

     
     list.add("hai");
     list.add("anu");
     list.add("Raj");
     list.addFirst("nani");
     list.addLast("Ram");
     list.add(2, "sam");
     Iterator<String> iterator=list.iterator();
     while(iterator.hasNext()){
       System.out.println(iterator.next());
     }
   } 
} 
