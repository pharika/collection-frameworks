import java.util.*; 
  
public class add { 
    public static void main(String[] args) 
        throws IllegalStateException 
    { 
  
         
        Queue<Integer> Q = new LinkedList<Integer>(); 
  
      
        Q.add(7231459); 
        Q.add(2341568); 
        Q.add(4532780); 
        Q.add(7543219); 
  
        
        System.out.println("Queue: " + Q); 
    } 
} 