import java.util.TreeSet; 
  
public class size { 
    public static void main(String args[]) 
    { 
  
        TreeSet<String> tree = new TreeSet<String>(); 
  
    
        tree.add("hello"); 
        tree.add("hii"); 
        tree.add("a"); 
        tree.add("2"); 
        tree.add("hey"); 
  
         
        System.out.println("TreeSet: " + tree); 
  
       
        System.out.println("The size of the set is: " + tree.size()); 
    } 
} 
