import java.util.TreeSet; 
  
public class clear{ 
    public static void main(String args[]) 
    { 
        
        TreeSet<String> tree = new TreeSet<String>(); 
  
        
        tree.add("hello"); 
        tree.add("hii"); 
        tree.add("a"); 
        tree.add("2"); 
        tree.add("hey"); 
         
  
        
        System.out.println("TreeSet: " + tree); 
  
        
        tree.clear(); 
  
         
        System.out.println("After clearing TreeSet: " + tree); 
    } 
} 