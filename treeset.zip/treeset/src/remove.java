
import java.util.TreeSet; 
  
public class remove{ 
    public static void main(String args[]) 
    { 
       
        TreeSet<String> tree = new TreeSet<String>(); 
  
        
        tree.add("hello"); 
        tree.add("hii"); 
        tree.add("a"); 
        tree.add("2"); 
        tree.add("hey"); 
       
       
        System.out.println("TreeSet: " + tree); 
  
         
        tree.remove("hello"); 
        tree.remove("2"); 
         
  
        
        System.out.println("New TreeSet: " + tree); 
    } 
} 