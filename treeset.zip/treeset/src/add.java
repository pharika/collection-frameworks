
import java.util.TreeSet; 
  
public class add { 
    public static void main(String args[]) 
    { 
 
        TreeSet<String> tree = new TreeSet<String>(); 
  

        tree.add("hello"); 
        tree.add("hi"); 
        tree.add("a"); 
        tree.add("2"); 
        tree.add("hey"); 
         
 
        System.out.println("TreeSet: " + tree); 
    } 
} 