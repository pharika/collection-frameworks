import java.util.Iterator;  
import java.util.ArrayList;  
import java.util.List;  
public class example {  
   public static void main(String[] args) {  
  List<String> list = new ArrayList<>();  
   list.add("Welcome");  
   list.add("to");  
   list.add("java");  
   list.add("collections");  
    System.out.println("The list is given as : "+list);  
    Iterator<String> a1 = list.iterator();  
         
   while(a1.hasNext()) {  
        
       System.out.println(a1.next());  
       }  
        
   a1.remove();  
   System.out.println("After the remove() method is called : "+list);  
   }  
}  
