import java.util.HashSet; 
  
public class add { 
    public static void main(String args[]) 
    { 
     
        HashSet<String> set = new HashSet<String>(); 
        set.add("Welcome"); 
        set.add("To"); 
        set.add("java"); 
        set.add("2"); 
        set.add("java"); 
        System.out.println("HashSet: " + set); 
    } 
} 
