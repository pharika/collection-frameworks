import java.util.*; 
public class remove { 
  
    public static void main(String args[]) 
    { 
  
        
        Map<Integer, String> a1= new HashMap<Integer, String>(); 
  
        
        a1.put(new Integer(1), "hello"); 
        a1.put(new Integer(2), "hi"); 
        a1.put(new Integer(3), "welcome"); 
         
  
        
        System.out.println(a1); 
  
        a1.remove(new Integer(2)); 
  
       
        System.out.println(a1); 
    } 
} 