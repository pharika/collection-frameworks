import java.util.*; 
public class change { 
    public static void main(String args[]) 
    { 
 
        Map<Integer, String> a1 = new HashMap<Integer, String>(); 
  
        // Inserting the Elements 
        a1.put(new Integer(1), "hello"); 
        a1.put(new Integer(2), "hi"); 
        a1.put(new Integer(3), "welcome"); 
  
        System.out.println("Initial Map " + a1); 
  
        a1.put(new Integer(2), "to"); 
  
        System.out.println("Updated Map " + a1); 
    } 
} 
