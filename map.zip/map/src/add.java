import java.util.*; 
public class add { 
    public static void main(String args[]) 
    { 
   
        Map<Integer, String> a1= new HashMap<>(); 
        a1.put(1, "hello"); 
        a1.put(2, "hi"); 
        a1.put(3, "welcome"); 
  
        
        System.out.println(a1); 
        
    } 
} 
